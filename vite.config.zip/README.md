# UXFocus

UXFocus is a desktop focus and scheduling app built with React, Tailwind CSS, and Electron.

## Development

Run `npm install` to install dependencies.

Run `npm run dev` to start the frontend development server, or `npm run desktop:dev` to open the desktop app with the development server.

Run `npm run build` to build the frontend.

## Local desktop app

Run `npm run docker:up` to build and update the local Docker service and launch UXFocus. On Windows, you can also use `scripts/start-uxfocus.vbs`.

Saved schedules, settings, and window state are stored in `.cache/electron-user-data`.
