# UXFocus development workflow

When changes require UXFocus to restart, automatically force-close UXFocus and reopen it after completing the necessary build and local Docker update. The user explicitly authorizes this workflow; do not ask for restart permission again.

- Identify UXFocus processes by the Electron executable in this workspace. Never terminate unrelated Electron apps or all Electron processes by name.
- Rebuild and update the local Docker service when the frontend or container configuration changes; rebuilding `dist` alone does not update the desktop app's served files.
- Reopen UXFocus using this project's launcher and preserve its saved schedule, settings, and window state.
- Verify that the service and desktop process restarted successfully, and report any failure honestly.
