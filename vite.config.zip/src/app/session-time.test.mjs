import assert from "node:assert/strict";
import test from "node:test";
import { getRemainingSessionSecs } from "./session-time.mjs";

const routine = { startTime: "05:30", endTime: "06:45" };
const at = (hour, minute, second = 0) => new Date(2026, 8, 11, hour, minute, second);

test("late morning routine starts with 45 minutes remaining", () => {
  assert.equal(getRemainingSessionSecs(routine, at(6, 0)), 45 * 60);
});

test("early starts add time and on-time starts retain the full duration", () => {
  assert.equal(getRemainingSessionSecs(routine, at(5, 0)), 105 * 60);
  assert.equal(getRemainingSessionSecs(routine, at(5, 30)), 75 * 60);
  assert.equal(getRemainingSessionSecs({ start: "07:00", end: "08:00" }, at(6, 50)), 70 * 60);
  assert.equal(getRemainingSessionSecs({ start: "07:00", end: "08:00" }, at(7, 10)), 50 * 60);
});

test("remaining time includes seconds and time spent paused", () => {
  assert.equal(getRemainingSessionSecs(routine, at(6, 0, 15)), 44 * 60 + 45);
  assert.equal(getRemainingSessionSecs(routine, at(6, 15)), 30 * 60);
});

test("finished or missing tasks have no remaining time", () => {
  assert.equal(getRemainingSessionSecs(routine, at(6, 45)), 0);
  assert.equal(getRemainingSessionSecs(routine, at(7, 0)), 0);
  assert.equal(getRemainingSessionSecs(null, at(6, 0)), 0);
});

test("supports schedule fields without time aliases", () => {
  assert.equal(getRemainingSessionSecs({ start: "05:30", end: "06:45" }, at(6, 0)), 2700);
});
