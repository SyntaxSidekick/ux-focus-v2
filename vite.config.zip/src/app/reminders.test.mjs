import test from 'node:test';
import assert from 'node:assert/strict';
import { advanceReminders, getReminderContent } from './reminders.mjs';
test('30 minutes posture; 60 minutes combined; repeats hourly', () => {
  assert.deepEqual(advanceReminders(0,1799000,7200).due, []);
  assert.deepEqual(advanceReminders(1799000,1000,7200).due, ['posture']);
  assert.deepEqual(advanceReminders(3599000,1000,3600).due, ['stretch','posture']);
  assert.equal(getReminderContent(['stretch','posture'], {}).kind, 'movement');
  assert.deepEqual(advanceReminders(3600000,1000,3600).due, []);
  assert.deepEqual(advanceReminders(7199000,1000,3600).due, ['stretch','posture']);
});
test('pauses, completion, reset and delayed ticks', () => {
  assert.deepEqual(advanceReminders(1200000,0,3600), {elapsedMs:1200000,due:[]});
  assert.deepEqual(advanceReminders(3599000,1000,0).due, []);
  assert.deepEqual(advanceReminders(0,1000,3600).due, []);
  assert.equal(getReminderContent(advanceReminders(0,7200000,3600).due, {}).kind,'movement');
});
test('each content collection rotates independently and wraps', () => {
  const rotations={};
  for(const types of [['posture'],['stretch'],['stretch','posture']]) {
    const titles=Array.from({length:4},()=>getReminderContent(types,rotations).title);
    assert.equal(new Set(titles.slice(0,3)).size,3);
    assert.equal(titles[0],titles[3]);
  }
});
test('custom interval and priority definitions', () => {
  const definitions=[{type:'water',intervalMs:1000,priority:3}];
  assert.deepEqual(advanceReminders(0,1000,1,definitions).due,['water']);
});
