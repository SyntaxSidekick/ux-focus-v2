import { useState, useEffect, useRef, useCallback, useSyncExternalStore } from "react";
import { parseScheduleImport } from "./schedule-import.mjs";
import { getRemainingSessionSecs } from "./session-time.mjs";
import { advanceReminders, getReminderContent } from "./reminders.mjs";
import {
  Settings, X, Play, Pause, RotateCcw,
  Plus, Trash2, Download, Upload, Bell,
} from "lucide-react";

interface ScheduleItem {
  id: string;
  label: string;
  title?: string;
  start: string;
  end: string;
  startTime: string;
  endTime: string;
  sound: "deepwork" | "break" | "default";
  completed?: boolean;
  reminderEnabled?: boolean;
  reminderLastTriggeredDate?: string;
  startReminderLastTriggeredDate?: string;
}

type ScheduleSound = ScheduleItem["sound"];
type TimeFormat = "24h" | "12h";
type ThemeId = "midnight" | "slate" | "forest" | "daylight";

const STORAGE_KEY = "uxfocus-schedule-v2";
const SETTINGS_KEY = "uxfocus-settings-v1";

interface AppSettings {
  timeFormat: TimeFormat;
  themeId: ThemeId;
  autoStart: boolean;
}

interface ThemePalette {
  id: ThemeId;
  name: string;
  swatches: string[];
  vars: React.CSSProperties;
}

const THEME_PALETTES: ThemePalette[] = [
  {
    id: "midnight",
    name: "Midnight",
    swatches: ["#111120", "#7c5cfc", "#22d3ee"],
    vars: {
      "--background": "#09090f",
      "--foreground": "#eeeef8",
      "--card": "#111120",
      "--card-foreground": "#eeeef8",
      "--primary": "#7c5cfc",
      "--primary-foreground": "#ffffff",
      "--secondary": "#1c1b2e",
      "--muted": "#1a1929",
      "--muted-foreground": "#8f8caf",
      "--accent": "#22d3ee",
      "--border": "rgba(255,255,255,0.08)",
      "--ring": "#7c5cfc",
    } as React.CSSProperties,
  },
  {
    id: "slate",
    name: "Slate",
    swatches: ["#18202b", "#4f8cff", "#f6c177"],
    vars: {
      "--background": "#10151d",
      "--foreground": "#eef3f8",
      "--card": "#18202b",
      "--card-foreground": "#eef3f8",
      "--primary": "#4f8cff",
      "--primary-foreground": "#ffffff",
      "--secondary": "#222c3a",
      "--muted": "#202a36",
      "--muted-foreground": "#9aa8b7",
      "--accent": "#f6c177",
      "--border": "rgba(238,243,248,0.09)",
      "--ring": "#4f8cff",
    } as React.CSSProperties,
  },
  {
    id: "forest",
    name: "Forest",
    swatches: ["#102019", "#34d399", "#f59e0b"],
    vars: {
      "--background": "#0b1511",
      "--foreground": "#edf8f2",
      "--card": "#102019",
      "--card-foreground": "#edf8f2",
      "--primary": "#34d399",
      "--primary-foreground": "#082018",
      "--secondary": "#1a2d24",
      "--muted": "#172820",
      "--muted-foreground": "#95ad9f",
      "--accent": "#f59e0b",
      "--border": "rgba(237,248,242,0.09)",
      "--ring": "#34d399",
    } as React.CSSProperties,
  },
  {
    id: "daylight",
    name: "Daylight",
    swatches: ["#ffffff", "#2563eb", "#e63757"],
    vars: {
      "--background": "#f5f7fb",
      "--foreground": "#151923",
      "--card": "#ffffff",
      "--card-foreground": "#151923",
      "--primary": "#2563eb",
      "--primary-foreground": "#ffffff",
      "--secondary": "#e8edf5",
      "--muted": "#eef2f8",
      "--muted-foreground": "#647084",
      "--accent": "#e63757",
      "--border": "rgba(21,25,35,0.11)",
      "--ring": "#2563eb",
    } as React.CSSProperties,
  },
];

const DEFAULT_SETTINGS: AppSettings = {
  timeFormat: "24h",
  themeId: "midnight",
  autoStart: true,
};

const DEFAULT_SCHEDULE: ScheduleItem[] = [
  { id: "1",  label: "Morning Review",                      start: "06:30", end: "07:00", startTime: "06:30", endTime: "07:00", sound: "default"  },
  { id: "2",  label: "Deep Work 1",                         start: "07:00", end: "08:30", startTime: "07:00", endTime: "08:30", sound: "deepwork" },
  { id: "3",  label: "Break",                               start: "08:30", end: "08:50", startTime: "08:30", endTime: "08:50", sound: "break"    },
  { id: "4",  label: "Audit Tokens & Components",           start: "08:50", end: "09:30", startTime: "08:50", endTime: "09:30", sound: "deepwork" },
  { id: "5",  label: "Build Design Token Foundation",       start: "09:30", end: "10:30", startTime: "09:30", endTime: "10:30", sound: "deepwork" },
  { id: "6",  label: "Break",                               start: "10:30", end: "10:50", startTime: "10:30", endTime: "10:50", sound: "break"    },
  { id: "7",  label: "Build Shared Component Library",      start: "10:50", end: "11:50", startTime: "10:50", endTime: "11:50", sound: "deepwork" },
  { id: "8",  label: "Implement Light & Dark Theme Toggle", start: "11:50", end: "12:30", startTime: "11:50", endTime: "12:30", sound: "deepwork" },
  { id: "9",  label: "Lunch Break",                         start: "12:30", end: "13:30", startTime: "12:30", endTime: "13:30", sound: "break"    },
  { id: "10", label: "Deep Work 2",                         start: "13:30", end: "15:00", startTime: "13:30", endTime: "15:00", sound: "deepwork" },
  { id: "11", label: "Break",                               start: "15:00", end: "15:20", startTime: "15:00", endTime: "15:20", sound: "break"    },
  { id: "12", label: "Review & Ship",                       start: "15:20", end: "16:30", startTime: "15:20", endTime: "16:30", sound: "default"  },
];

function isScheduleSound(value: unknown): value is ScheduleItem["sound"] {
  return value === "deepwork" || value === "break" || value === "default";
}

function normalizeScheduleItem(item: unknown, index: number): ScheduleItem | null {
  if (!item || typeof item !== "object") return null;
  const raw = item as Record<string, unknown>;
  const label = typeof raw.label === "string" ? raw.label : typeof raw.title === "string" ? raw.title : "";
  const start = typeof raw.start === "string" ? raw.start : typeof raw.startTime === "string" ? raw.startTime : "";
  const end = typeof raw.end === "string" ? raw.end : typeof raw.endTime === "string" ? raw.endTime : "";
  if (!label || !isValidTime(start) || !isValidTime(end)) return null;

  return {
    ...raw,
    id: typeof raw.id === "string" ? raw.id : `${Date.now()}-${index}`,
    label,
    title: typeof raw.title === "string" ? raw.title : label,
    start,
    end,
    startTime: typeof raw.startTime === "string" ? raw.startTime : start,
    endTime: typeof raw.endTime === "string" ? raw.endTime : end,
    sound: isScheduleSound(raw.sound) ? raw.sound : "default",
    completed: typeof raw.completed === "boolean" ? raw.completed : undefined,
    reminderEnabled: typeof raw.reminderEnabled === "boolean" ? raw.reminderEnabled : undefined,
    startReminderLastTriggeredDate: typeof raw.startReminderLastTriggeredDate === "string" ? raw.startReminderLastTriggeredDate : undefined,
    reminderLastTriggeredDate: typeof raw.reminderLastTriggeredDate === "string" ? raw.reminderLastTriggeredDate : undefined,
  };
}

function normalizeSchedule(value: unknown): ScheduleItem[] | null {
  if (!Array.isArray(value)) return null;
  const schedule = value.map(normalizeScheduleItem);
  if (schedule.some(item => item === null)) return null;
  return schedule as ScheduleItem[];
}

const unreadableStorageKeys = new Set<string>();
type AppNotice = { message: string; error: boolean };
let notices: AppNotice[] = [];
const noticeListeners = new Set<() => void>();
const subscribeNotices = (listener: () => void) => { noticeListeners.add(listener); return () => { noticeListeners.delete(listener); }; };
const getNotices = () => notices;
function showNotice(message: string, error = true) {
  if (notices.some(notice => notice.message === message)) return;
  const notice = { message, error };
  notices = [...notices, notice];
  queueMicrotask(() => noticeListeners.forEach(listener => listener()));
  setTimeout(() => dismissNotice(notice), error ? 8000 : 4000);
}
function dismissNotice(notice: AppNotice) {
  notices = notices.filter(item => item !== notice);
  noticeListeners.forEach(listener => listener());
}
function errorDetail(error: unknown) { return error instanceof Error ? error.message : "Unexpected error."; }

function readSavedValue(key: string): string | null {
  try {
    const desktop = window.uxFocusStorage;
    const saved = desktop?.getItem(key);
    if (saved != null) return saved;
    const legacy = localStorage.getItem(key);
    if (legacy != null && desktop) desktop.setItem(key, legacy);
    return legacy;
  } catch (error) {
    unreadableStorageKeys.add(key);
    throw error;
  }
}

function writeSavedValue(key: string, value: string) {
  try {
    if (unreadableStorageKeys.has(key)) throw new Error("The existing save could not be read; refusing to overwrite it.");
    if (window.uxFocusStorage) window.uxFocusStorage.setItem(key, value);
    else localStorage.setItem(key, value);
  } catch (error) {
    console.error("Unable to save UX Focus data", error);
    showNotice(`Changes could not be saved: ${errorDetail(error)} Export your schedule before closing UXFocus. Check disk space and folder access, then retry.`);
  }
}

function loadSchedule(): ScheduleItem[] {
  try {
    const raw = readSavedValue(STORAGE_KEY);
    if (raw) {
      const parsed = normalizeSchedule(JSON.parse(raw));
      if (parsed) return parsed;
      throw new Error("Saved schedule has an invalid format");
    }
  } catch (error) {
    unreadableStorageKeys.add(STORAGE_KEY);
    console.error("Unable to load schedule", error);
    showNotice(`Saved schedule could not be loaded: ${errorDetail(error)} Your saved file is unchanged. Check the saved file before making further changes.`);
  }
  return DEFAULT_SCHEDULE;
}

function saveSchedule(schedule: ScheduleItem[]) {
  writeSavedValue(STORAGE_KEY, JSON.stringify(schedule));
}

function isTimeFormat(value: unknown): value is TimeFormat {
  return value === "24h" || value === "12h";
}

function isThemeId(value: unknown): value is ThemeId {
  return THEME_PALETTES.some(theme => theme.id === value);
}

function loadSettings(): AppSettings {
  try {
    const raw = readSavedValue(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Record<string, unknown>;
      return {
        timeFormat: isTimeFormat(parsed.timeFormat) ? parsed.timeFormat : DEFAULT_SETTINGS.timeFormat,
        themeId: isThemeId(parsed.themeId) ? parsed.themeId : DEFAULT_SETTINGS.themeId,
        autoStart: typeof parsed.autoStart === "boolean" ? parsed.autoStart : true,
      };
    }
  } catch (error) {
    unreadableStorageKeys.add(SETTINGS_KEY);
    showNotice(`Settings could not be loaded: ${errorDetail(error)} Defaults are shown. Your saved settings have been preserved.`);
  }
  return DEFAULT_SETTINGS;
}

function saveSettings(settings: AppSettings) {
  writeSavedValue(SETTINGS_KEY, JSON.stringify(settings));
}

function timeToMinutes(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function isValidTime(t: string) {
  const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(t);
  return Boolean(match);
}

function getSessionDurationSecs(item: ScheduleItem | null): number {
  if (!item) return 0;
  const start = timeToMinutes(item.startTime ?? item.start);
  const end = timeToMinutes(item.endTime ?? item.end);
  return Math.max(0, end - start) * 60;
}

function formatTimer(secs: number): string {
  const hours = Math.floor(secs / 3600);
  const minutes = Math.floor((secs % 3600) / 60);
  const seconds = secs % 60;
  if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function formatClock(date: Date, timeFormat: TimeFormat) {
  return date.toLocaleTimeString("en-US", {
    hour12: timeFormat === "12h",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function localDateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

let timerAudioContext: AudioContext | null = null;

function getTimerAudioContext(): AudioContext | null {
  const audioWindow = window as Window & { webkitAudioContext?: typeof AudioContext };
  const AudioContextCtor = window.AudioContext ?? audioWindow.webkitAudioContext;
  if (!AudioContextCtor) return null;
  if (!timerAudioContext) timerAudioContext = new AudioContextCtor();
  return timerAudioContext;
}

function resumeTimerAudio() {
  const ctx = getTimerAudioContext();
  if (ctx?.state === "suspended") void ctx.resume();
}

function playTone(ctx: AudioContext, startAt: number, frequency: number, duration: number, volume: number, type: OscillatorType = "sine", sustain = false) {
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();
  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, startAt);
  gain.gain.setValueAtTime(0.0001, startAt);
  gain.gain.exponentialRampToValueAtTime(volume, startAt + 0.025);
  if (sustain) gain.gain.setValueAtTime(volume, startAt + duration - 0.04);
  gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);
  oscillator.connect(gain);
  gain.connect(ctx.destination);
  oscillator.start(startAt);
  oscillator.stop(startAt + duration + 0.04);
  oscillator.onended = () => {
    oscillator.disconnect();
    gain.disconnect();
  };
}

let completionAlarmEndsAt = 0;

function playCompletionAlarm() {
  const ctx = getTimerAudioContext();
  if (!ctx) return;
  if (ctx.state === "suspended") void ctx.resume();
  // Avoid overlapping alarms if completion is processed more than once.
  if (ctx.currentTime < completionAlarmEndsAt) return;

  const startAt = ctx.currentTime + 0.02;
  // Six groups of alternating, sustained beeps, like a digital alarm clock.
  for (let group = 0; group < 6; group += 1) {
    for (let pulse = 0; pulse < 3; pulse += 1) {
      playTone(ctx, startAt + group + pulse * 0.24, pulse === 1 ? 1046.5 : 783.99, 0.18, 0.22, "square", true);
    }
  }
  completionAlarmEndsAt = startAt + 5.7;
}

function playScheduleSound(sound: unknown) {
  const ctx = getTimerAudioContext();
  if (!ctx) return;
  if (ctx.state === "suspended") void ctx.resume();

  const soundType: ScheduleSound = isScheduleSound(sound) ? sound : "default";
  const now = ctx.currentTime + 0.02;

  if (soundType === "deepwork") {
    playTone(ctx, now, 523.25, 0.28, 0.16);
    playTone(ctx, now + 0.22, 659.25, 0.3, 0.15);
    playTone(ctx, now + 0.46, 783.99, 0.42, 0.13);
    return;
  }

  if (soundType === "break") {
    playTone(ctx, now, 659.25, 0.24, 0.1, "triangle");
    playTone(ctx, now + 0.3, 523.25, 0.35, 0.09, "triangle");
    return;
  }

  playTone(ctx, now, 587.33, 0.22, 0.12);
  playTone(ctx, now + 0.28, 587.33, 0.28, 0.1);
}

function playTaskChime(item: ScheduleItem, atStart: boolean) {
  // Short, soft melodic chimes are separate from the repeating completion alarm.
  const ctx = getTimerAudioContext();
  if (!ctx) return;
  void ctx.resume().then(() => {
    let hash = 2166136261;
    for (const char of item.id + item.label) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619) >>> 0;
    const notes = [0, 2, 4, 7, 9];
    const base = item.sound === "break" ? 440 : item.sound === "deepwork" ? 523.25 : 587.33;
    for (let index = 0; index < 4; index++) {
      const step = notes[(hash >>> (index * 3)) % notes.length] + (atStart ? index : 3 - index);
      playTone(ctx, ctx.currentTime + 0.02 + index * 0.24, base * 2 ** (step / 12), 0.4, 0.12, item.sound === "break" ? "triangle" : "sine");
    }
  }).catch(console.error);
}

function getCurrentBlock(schedule: ScheduleItem[]): ScheduleItem | null {
  return schedule.find(item => !item.completed) ?? null;
}

function getDayProgress(schedule: ScheduleItem[]): number {
  if (!schedule.length) return 0;
  return schedule.filter(i => i.completed).length / schedule.length;
}

// ─── Block type tag ────────────────────────────────────────────────────────────
function BlockTag({ type }: { type: ScheduleItem["sound"] }) {
  const styles = {
    deepwork: "bg-violet-500/15 text-violet-300 border-violet-500/20",
    break:    "bg-emerald-500/15 text-emerald-300 border-emerald-500/20",
    default:  "bg-sky-500/15 text-sky-300 border-sky-500/20",
  };
  const labels = { deepwork: "Focus", break: "Break", default: "Task" };
  return (
    <span className={`inline-flex text-[9px] font-semibold uppercase tracking-widest px-2 py-0.5 rounded-full border ${styles[type]}`}>
      {labels[type]}
    </span>
  );
}

// ─── Pomodoro timer face ───────────────────────────────────────────────────────
function PomodoroFace({ progress, timeDisplay, isRunning, totalSecs }: {
  progress: number; timeDisplay: string; isRunning: boolean; totalSecs: number;
}) {
  const SIZE = 180;
  const CX = SIZE / 2;
  const R_OUTER = 80;
  const R_INNER = 66;
  const STROKE = 7;
  const circ = 2 * Math.PI * R_OUTER;
  const offset = circ * (1 - progress);

  // tick marks at every 5-minute interval
  const TICKS = 12;
  const ticks = Array.from({ length: TICKS }, (_, i) => {
    const angle = (i / TICKS) * 2 * Math.PI - Math.PI / 2;
    const major = i % 3 === 0;
    const rOuter = R_OUTER + 10;
    const rInner = rOuter - (major ? 8 : 5);
    return {
      x1: CX + rInner * Math.cos(angle),
      y1: CX + rInner * Math.sin(angle),
      x2: CX + rOuter * Math.cos(angle),
      y2: CX + rOuter * Math.sin(angle),
      major,
    };
  });

  const pct = Math.round(progress * 100);

  return (
    <div className="relative flex items-center justify-center" style={{ width: SIZE, height: SIZE }}>
      <svg
        width={SIZE} height={SIZE} viewBox={`0 0 ${SIZE} ${SIZE}`}
        className="absolute inset-0 -rotate-90"
      >
        {/* Outer glow ring when running */}
        {isRunning && (
          <circle
            cx={CX} cy={CX} r={R_OUTER}
            fill="none"
            stroke="var(--primary)"
            strokeWidth={STROKE + 6}
            strokeDasharray={circ}
            strokeDashoffset={offset}
            opacity="0.12"
            style={{ transition: "stroke-dashoffset 1s linear" }}
          />
        )}
        {/* Track */}
        <circle cx={CX} cy={CX} r={R_OUTER} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={STROKE} />
        {/* Progress arc */}
        <circle
          cx={CX} cy={CX} r={R_OUTER}
          fill="none"
          stroke="url(#pomoGrad)"
          strokeWidth={STROKE}
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1s linear" }}
        />
        {/* Inner filled circle (face bg) */}
        <circle cx={CX} cy={CX} r={R_INNER} fill="rgba(255,255,255,0.03)" />
        {/* Inner border */}
        <circle cx={CX} cy={CX} r={R_INNER} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />

        {/* Gradient def */}
        <defs>
          <linearGradient id="pomoGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={isRunning ? "var(--primary)" : "var(--muted)"} />
            <stop offset="100%" stopColor={isRunning ? "var(--accent)" : "var(--secondary)"} />
          </linearGradient>
        </defs>
      </svg>

      {/* Tick marks (not rotated — drawn in normal space) */}
      <svg width={SIZE} height={SIZE} viewBox={`0 0 ${SIZE} ${SIZE}`} className="absolute inset-0">
        {ticks.map((t, i) => (
          <line
            key={i}
            x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2}
            stroke={t.major ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.08)"}
            strokeWidth={t.major ? 1.5 : 1}
            strokeLinecap="round"
          />
        ))}
      </svg>

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center select-none">
        <span
          className="text-[30px] font-semibold tracking-widest leading-none text-foreground"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}
        >
          {timeDisplay}
        </span>
        <span className="text-[9px] uppercase tracking-[0.25em] text-muted-foreground mt-1.5">
          {isRunning ? `${pct}% elapsed` : "pomodoro"}
        </span>
      </div>
    </div>
  );
}

// ─── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  const importInput = useRef<HTMLInputElement>(null);
  const appNotices = useSyncExternalStore(subscribeNotices, getNotices);
  const [reminderNotice, setReminderNotice] = useState<{ title: string; message: string; icon?: string } | null>(null);
  const [now, setNow]                     = useState(new Date());
  const [settings, setSettingsRaw]        = useState<AppSettings>(() => loadSettings());
  const [showSettings, setShowSettings]   = useState(false);
  const [showAddForm, setShowAddForm]     = useState(false);
  const initialSchedule                   = useRef<ScheduleItem[] | null>(null);
  const [schedule, setScheduleRaw]        = useState<ScheduleItem[]>(() => {
    const loaded = loadSchedule();
    initialSchedule.current = loaded;
    return loaded;
  });
  const autoStart = settings.autoStart;
  const [pomodoroSecs, setPomodoroSecs]   = useState(() => getSessionDurationSecs(getCurrentBlock(initialSchedule.current ?? DEFAULT_SCHEDULE)));
  const [pomodoroRunning, setPomodoroRunning] = useState(false);
  const [sessionTotalSecs, setSessionTotalSecs] = useState(pomodoroSecs);
  const reminderElapsedMs = useRef(0);
  const reminderRotations = useRef<Record<string, number>>({});
  const [newTask, setNewTask]             = useState({ label: "", start: "", end: "", sound: "deepwork" as ScheduleItem["sound"] });

  const setSettings = useCallback((updater: AppSettings | ((prev: AppSettings) => AppSettings)) => {
    setSettingsRaw(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveSettings(next);
      return next;
    });
  }, []);

  // Persist schedule whenever it changes
  const setSchedule = useCallback((updater: ScheduleItem[] | ((prev: ScheduleItem[]) => ScheduleItem[])) => {
    setScheduleRaw(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveSchedule(next);
      return next;
    });
  }, []);

  useEffect(() => { const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, []);

  useEffect(() => {
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const today = localDateKey(now);
    const due = schedule.find(item => !item.completed && item.reminderEnabled !== false && (
      (item.startReminderLastTriggeredDate !== today && currentMinutes === timeToMinutes(item.start)) ||
      (item.reminderLastTriggeredDate !== today && currentMinutes >= timeToMinutes(item.start) - 5 && currentMinutes < timeToMinutes(item.start))
    ));
    if (!due) return;
    const atStart = currentMinutes === timeToMinutes(due.start);
    setSchedule(items => items.map(item => item.id === due.id ? { ...item, [atStart ? "startReminderLastTriggeredDate" : "reminderLastTriggeredDate"]: today } : item));
    playTaskChime(due, atStart);
    setReminderNotice({ title: atStart ? "Time to start" : "Coming up", message: due.label + " (" + due.start + ")", icon: "\u{1F514}" });
    void window.uxFocusWindow?.showReminder({ label: due.label, start: due.start, atStart });
  }, [now, schedule, setSchedule]);

  const currentBlock   = getCurrentBlock(schedule);
  const currentDurationSecs = getSessionDurationSecs(currentBlock);
  const dayProgress    = getDayProgress(schedule);
  const completedCount = schedule.filter(i => i.completed).length;
  const pomoProgress   = sessionTotalSecs > 0 ? Math.max(0, 1 - pomodoroSecs / sessionTotalSecs) : 0;
  const pomoDisplay    = formatTimer(pomodoroSecs);
  const activeTheme    = THEME_PALETTES.find(theme => theme.id === settings.themeId) ?? THEME_PALETTES[0];
  const timeDisplay    = formatClock(now, settings.timeFormat);

  useEffect(() => {
    if (!pomodoroRunning) return;
    let previousTick = Date.now();
    const id = setInterval(() => {
      const tick = Date.now();
      const remaining = getRemainingSessionSecs(currentBlock, new Date(tick));
      const reminder = advanceReminders(reminderElapsedMs.current, tick - previousTick, remaining);
      previousTick = tick;
      reminderElapsedMs.current = reminder.elapsedMs;
      setPomodoroSecs(remaining);
      if (remaining <= 0) {
        playCompletionAlarm();
        setPomodoroRunning(false);
      } else if (reminder.due.length) {
        const content = getReminderContent(reminder.due, reminderRotations.current);
        if (!content) return;
        setReminderNotice(content);
        const ctx = getTimerAudioContext();
        if (ctx) {
          void ctx.resume().then(() => {
            playTone(ctx, ctx.currentTime + 0.02, 880, 0.25, 0.15, "triangle");
            playTone(ctx, ctx.currentTime + 0.35, 440, 0.4, 0.15, "triangle");
          });
        }
        void window.uxFocusWindow?.showReminder(content);
      }
    }, 1000);
    return () => clearInterval(id);
  }, [pomodoroRunning, currentBlock?.id, currentBlock?.endTime, currentBlock?.end]);

  useEffect(() => {
    setPomodoroRunning(false);
    setPomodoroSecs(getSessionDurationSecs(currentBlock));
    setSessionTotalSecs(getSessionDurationSecs(currentBlock));
    reminderElapsedMs.current = 0;
  }, [currentBlock?.id, currentBlock?.startTime, currentBlock?.endTime, currentBlock?.start, currentBlock?.end]);

  const addTask = () => {
    if (!newTask.label || !newTask.start || !newTask.end) return;
    const item: ScheduleItem = { ...newTask, id: Date.now().toString(), title: newTask.label, startTime: newTask.start, endTime: newTask.end };
    setSchedule(s => [...s, item].sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start)));
    setNewTask({ label: "", start: "", end: "", sound: "deepwork" });
    setShowAddForm(false);
  };

  const handleExport = () => {
    try {
    const blob = new Blob([JSON.stringify({ schedule }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    Object.assign(document.createElement("a"), { href: url, download: "uxfocus-schedule.json" }).click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) { showNotice(`Export failed: ${errorDetail(error)} Try exporting again before closing UXFocus.`); }
  };

  const handleImport = () => {
    importInput.current?.click();
  };

  return (
    <div className="h-dvh bg-transparent p-1" style={activeTheme.vars}>
      <input ref={importInput} type="file" accept=".json,application/json" hidden onChange={async e => {
        const file = e.currentTarget.files?.[0];
        e.currentTarget.value = "";
        if (!file) return;
        try {
          const imported = normalizeSchedule(parseScheduleImport(await file.text()));
          if (!imported) throw new Error("The schedule contains invalid tasks.");
          if (unreadableStorageKeys.has(STORAGE_KEY)) throw new Error("Existing saved data could not be read. Export your schedule before repairing the saved file.");
          // Save before reporting success or replacing the visible schedule.
          const storage = window.uxFocusStorage ?? localStorage;
          storage.setItem(STORAGE_KEY, JSON.stringify(imported));
          setScheduleRaw(imported);
          showNotice(`Imported and saved ${imported.length} tasks from ${file.name}.`, false);
        } catch (error) {
          showNotice(`Could not import ${file.name}: ${errorDetail(error)} Check the file and try again. Your current schedule has not been replaced.`);
        }
      }} />
      <div
        onPointerDown={resumeTimerAudio}
        style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        className="flex h-full flex-col bg-card border border-border rounded-2xl shadow-2xl overflow-y-auto [&>*]:shrink-0"
      >
        <div className="sticky top-0 z-20 max-h-[40vh] overflow-y-auto bg-card">
          {appNotices.map(notice => <div key={notice.message} role={notice.error ? "alert" : "status"} className={`mx-3 my-2 rounded-lg border p-3 text-xs ${notice.error ? "border-red-400/50 bg-red-500/10" : "border-emerald-400/50 bg-emerald-500/10"}`}>
            <div className="flex items-center justify-between gap-2"><strong>{notice.error ? "Something went wrong" : "Success"}</strong><button aria-label="Dismiss message" onClick={() => dismissNotice(notice)}><X size={14} /></button></div>
            <p className="mt-1 break-words">{notice.message}</p>
          </div>)}
        </div>

        {/* ── Title bar ────────────────────────────────────────── */}
        <div
          style={{ WebkitAppRegion: "drag" } as React.CSSProperties}
          className="flex cursor-grab items-center justify-between px-4 pt-3.5 pb-2.5 active:cursor-grabbing"
        >
          <span className="text-[15px] font-bold tracking-[0.18em] uppercase">
            <span className="text-primary">ux</span>
            <span className="text-foreground">Focus</span>
          </span>

          <div className="flex items-center gap-2" style={{ WebkitAppRegion: "no-drag" } as React.CSSProperties}>
            <button
              onClick={() => { setShowSettings(s => !s); setShowAddForm(false); }}
              className={`p-1.5 rounded-lg transition-colors ${showSettings ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary"}`}
              title="Settings"
            >
              <Settings size={13} />
            </button>

            <div className="w-px h-3.5 bg-border mx-0.5" />

            {/* Traffic lights */}
            <div className="flex items-center gap-1.5">
              <button onClick={() => window.uxFocusWindow?.minimize()} title="Minimize"
                className="group w-3 h-3 rounded-full bg-yellow-400 hover:bg-yellow-300 flex items-center justify-center transition-colors">
                <span className="w-1.5 h-px bg-yellow-900/60 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
              <button onClick={() => window.uxFocusWindow?.toggleFullHeight?.()} title="Maximize / restore height" aria-label="Maximize / restore height"
                className="w-3 h-3 rounded-full bg-green-400 hover:bg-green-300 flex items-center justify-center transition-colors" />
              <button onClick={() => window.uxFocusWindow?.close()} title="Close"
                className="group w-3 h-3 rounded-full bg-red-400 hover:bg-red-300 flex items-center justify-center transition-colors">
                <X size={6} className="text-red-900/60 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            </div>
          </div>
        </div>

        {/* ── Settings panel ───────────────────────────────────── */}
        {showSettings && (
          <div className="mx-4 mb-3 rounded-xl border border-border bg-secondary/40 px-3 py-3 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Auto-start Pomodoro on Focus</span>
              <button
                onClick={() => setSettings(s => ({ ...s, autoStart: !s.autoStart }))}
                className={`relative w-9 h-5 rounded-full transition-colors duration-300 ${autoStart ? "bg-primary" : "bg-muted-foreground/30"}`}
              >
                <span className={`absolute top-[3px] left-[3px] w-3.5 h-3.5 rounded-full bg-white shadow-sm transition-transform duration-300 ${autoStart ? "translate-x-4" : "translate-x-0"}`} />
              </button>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs text-muted-foreground">Time format</span>
              <div className="grid grid-cols-2 rounded-lg border border-border bg-card/40 p-0.5">
                {(["24h", "12h"] as TimeFormat[]).map(format => (
                  <button
                    key={format}
                    onClick={() => setSettings(s => ({ ...s, timeFormat: format }))}
                    className={`px-2.5 py-1 text-[10px] rounded-md transition-colors ${
                      settings.timeFormat === format
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {format === "24h" ? "Military" : "Standard"}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <span className="text-xs text-muted-foreground">Theme</span>
              <div className="grid grid-cols-2 gap-2">
                {THEME_PALETTES.map(theme => (
                  <button
                    key={theme.id}
                    onClick={() => setSettings(s => ({ ...s, themeId: theme.id }))}
                    className={`flex items-center justify-between rounded-lg border px-2.5 py-2 text-[10px] transition-colors ${
                      settings.themeId === theme.id
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border bg-card/35 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <span>{theme.name}</span>
                    <span className="flex -space-x-1">
                      {theme.swatches.map(color => (
                        <span
                          key={color}
                          className="h-3.5 w-3.5 rounded-full border border-card"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </span>
                  </button>
                ))}
              </div>
            </div>
            <div className="h-px bg-border/60" />
            <div className="space-y-2">
              <span className="text-xs text-muted-foreground">Schedule</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => { setShowAddForm(s => !s); setShowSettings(false); }}
                  className="flex items-center justify-center gap-1.5 rounded-lg bg-primary px-2.5 py-2 text-[10px] font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                >
                  <Plus size={12} /> Add Event
                </button>
                <button
                  onClick={() => { setSchedule(DEFAULT_SCHEDULE); }}
                  className="rounded-lg border border-border bg-card/35 px-2.5 py-2 text-[10px] text-muted-foreground transition-colors hover:text-destructive"
                >
                  Reset Schedule
                </button>
                <button
                  onClick={handleExport}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-border bg-card/35 px-2.5 py-2 text-[10px] text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Download size={12} /> Export
                </button>
                <button
                  onClick={handleImport}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-border bg-card/35 px-2.5 py-2 text-[10px] text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Upload size={12} /> Import
                </button>
              </div>
            </div>
            <div className="h-px bg-border/60" />
            <button
              onClick={() => setShowSettings(false)}
              className="w-full text-center text-[10px] text-muted-foreground hover:text-foreground transition-colors"
            >
              Close Settings
            </button>
          </div>
        )}

        {/* ── Clock (centered) ─────────────────────────────────── */}
        <div className="px-4 pb-3 text-center">
          <div className="flex items-end justify-center gap-1.5 leading-none">
            <span
              className="text-[48px] font-semibold tracking-tight text-foreground"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              {timeDisplay}
            </span>
            <span
              className="text-xl text-muted-foreground mb-1.5 font-normal"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              {String(now.getSeconds()).padStart(2, "0")}
            </span>
          </div>
          <p className="text-[11px] text-muted-foreground mt-1">
            {now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
          </p>
        </div>

        {/* ── Current block ────────────────────────────────────── */}
        <div className="px-4 pb-4">
          {currentBlock ? (
            <div className="rounded-xl border border-border bg-secondary/40 p-3">
              <div className="flex items-start justify-between gap-2 mb-2.5">
                <div className="min-w-0">
                  <p className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground mb-1">Working On</p>
                  <p className="text-sm font-semibold text-foreground leading-snug">{currentBlock.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{currentBlock.start} – {currentBlock.end}</p>
                </div>
                <BlockTag type={currentBlock.sound} />
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${dayProgress * 100}%`,
                      background: "linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%)",
                      boxShadow: "0 0 8px color-mix(in srgb, var(--primary) 45%, transparent)",
                    }}
                  />
                </div>
                <span className="text-[9px] text-muted-foreground tabular-nums flex-shrink-0">
                  {completedCount}/{schedule.length}
                </span>
              </div>
            </div>
          ) : schedule.length > 0 ? (
            <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-emerald-400">All tasks complete!</p>
                <span className="text-[9px] text-emerald-400/70">{schedule.length}/{schedule.length}</span>
              </div>
              <div className="h-[3px] rounded-full" style={{ background: "linear-gradient(90deg, var(--primary), var(--accent))" }} />
            </div>
          ) : (
            <div className="rounded-xl border border-border bg-secondary/20 p-3 text-center">
              <p className="text-xs text-muted-foreground">No tasks scheduled</p>
            </div>
          )}
        </div>

        <div className="h-px bg-border mx-4" />

        {/* ── Pomodoro ─────────────────────────────────────────── */}
        <div className="px-4 py-5 flex flex-col items-center gap-4">
          <PomodoroFace
            progress={pomoProgress}
            timeDisplay={pomoDisplay}
            isRunning={pomodoroRunning}
            totalSecs={pomodoroSecs}
          />
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                resumeTimerAudio();
                if (pomodoroRunning) {
                  setPomodoroRunning(false);
                  return;
                }
                const remaining = getRemainingSessionSecs(currentBlock);
                const seconds = remaining;
                setSessionTotalSecs(Math.max(sessionTotalSecs, seconds));
                setPomodoroSecs(seconds);
                setPomodoroRunning(seconds > 0);
              }}
              className="flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground text-xs font-semibold rounded-xl hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-primary/25"
            >
              {pomodoroRunning ? <Pause size={13} /> : <Play size={13} />}
              {pomodoroRunning ? "Pause" : "Start"}
            </button>
            <button
              onClick={() => { setPomodoroRunning(false); setPomodoroSecs(currentDurationSecs); setSessionTotalSecs(currentDurationSecs); reminderElapsedMs.current = 0; }}
              className="p-2.5 rounded-xl border border-border text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
              title="Reset"
            >
              <RotateCcw size={14} />
            </button>
          </div>
          <p className="text-[10px] text-muted-foreground">While running: switch every 30 min / stretch every 60 min</p>
        </div>

        <div className="h-px bg-border mx-4" />

        {/* ── Schedule ─────────────────────────────────────────── */}
        <div className="px-4 pt-3 pb-1.5 flex items-center justify-between">
          <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Schedule</span>
          <button
            onClick={() => { setShowAddForm(s => !s); setShowSettings(false); }}
            className={`p-1 rounded-lg transition-colors ${showAddForm ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary"}`}
          >
            <Plus size={13} />
          </button>
        </div>

        {reminderNotice && <div role="status" className="mx-4 my-2 rounded-lg border border-current bg-card p-3 text-xs text-card-foreground"><p className="font-semibold">{reminderNotice.icon} {reminderNotice.title}</p><p className="mt-1 leading-relaxed">{reminderNotice.message}</p><button className="mt-3 rounded-md border border-current px-3 py-1.5 font-semibold hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current" onClick={() => setReminderNotice(null)}>Dismiss</button></div>}
        <p className="px-4 pb-2 text-[10px] text-muted-foreground">Bell: 5 minutes before + at start. Task-specific chimes.</p>
        {/* Add task form */}
        {showAddForm && (
          <div className="px-4 pb-3 space-y-2">
            <input
              placeholder="Task name"
              value={newTask.label}
              onChange={e => setNewTask(t => ({ ...t, label: e.target.value }))}
              onKeyDown={e => e.key === "Enter" && addTask()}
              className="w-full text-xs px-3 py-2 rounded-lg border border-border bg-secondary/60 text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary/60 transition-colors"
            />
            <div className="flex gap-2">
              <input type="time" value={newTask.start}
                onChange={e => setNewTask(t => ({ ...t, start: e.target.value }))}
                className="flex-1 text-xs px-3 py-2 rounded-lg border border-border bg-secondary/60 text-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
              <input type="time" value={newTask.end}
                onChange={e => setNewTask(t => ({ ...t, end: e.target.value }))}
                className="flex-1 text-xs px-3 py-2 rounded-lg border border-border bg-secondary/60 text-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
            <select value={newTask.sound}
              onChange={e => setNewTask(t => ({ ...t, sound: e.target.value as ScheduleItem["sound"] }))}
              className="w-full text-xs px-3 py-2 rounded-lg border border-border bg-secondary/60 text-foreground focus:outline-none focus:border-primary/60 transition-colors"
            >
              <option value="deepwork">Deep Work</option>
              <option value="break">Break</option>
              <option value="default">Other</option>
            </select>
            <button onClick={addTask}
              className="w-full py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-xl hover:opacity-90 transition-opacity"
            >
              Add to Schedule
            </button>
          </div>
        )}

        {/* Schedule rows with alternating bg */}
        <div className="min-h-[120px] flex-1 pb-2 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
          {schedule.map((item, idx) => {
            const isActive = item.id === currentBlock?.id;
            const isDone   = !!item.completed;
            const isEven   = idx % 2 === 0;
            return (
              <div
                key={item.id}
                aria-current={isActive ? "time" : undefined}
                className={`group flex items-center gap-2.5 px-4 py-2.5 transition-all ${
                  isActive
                    ? "bg-primary/25 border-l-2 border-l-primary ring-1 ring-inset ring-primary/40"
                    : isEven
                    ? "bg-secondary/30"
                    : "bg-transparent"
                }`}
              >
                {/* Checkbox */}
                <button
                  onClick={() => setSchedule(s => s.map(i => i.id === item.id ? { ...i, completed: !i.completed } : i))}
                  className={`flex-shrink-0 w-[15px] h-[15px] rounded-[4px] border flex items-center justify-center transition-all ${
                    isDone
                      ? "bg-primary border-primary"
                      : isActive
                      ? "border-primary bg-primary/15 hover:bg-primary/30"
                      : "border-muted-foreground/25 hover:border-muted-foreground/60"
                  }`}
                >
                  {isDone && (
                    <svg width="9" height="7" viewBox="0 0 9 7" fill="none">
                      <path d="M1 3.5L3.5 6L8 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>

                {/* Label + time */}
                <div className="flex-1 min-w-0">
                  <p title={item.label} className={`text-xs font-medium truncate transition-colors ${
                    isDone
                      ? "text-muted-foreground/35 line-through decoration-muted-foreground/25"
                      : isActive
                      ? "text-foreground"
                      : "text-muted-foreground"
                  }`}>
                    {item.label}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className={`text-[10px] ${isActive ? "text-foreground/85" : "text-muted-foreground/45"}`}>{item.start} – {item.end}</p>
                    {isActive && (
                      <span className="inline-flex shrink-0 items-center gap-1 rounded bg-primary px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-primary-foreground">
                        <span className="h-1 w-1 rounded-full bg-current" aria-hidden="true" />
                        Active
                      </span>
                    )}
                  </div>
                </div>

                {/* Type dot */}
                <div className={`w-1 h-1 rounded-full flex-shrink-0 ${
                  item.sound === "deepwork" ? "bg-violet-400/50"
                  : item.sound === "break"  ? "bg-emerald-400/50"
                  : "bg-sky-400/50"
                }`} />

                <button onClick={() => { resumeTimerAudio(); setSchedule(s => s.map(i => i.id === item.id ? { ...i, reminderEnabled: i.reminderEnabled === false, reminderLastTriggeredDate: undefined, startReminderLastTriggeredDate: undefined } : i)); }}
                  className={`p-1 rounded transition-all flex-shrink-0 ${item.reminderEnabled !== false ? "text-amber-400 bg-amber-400/10" : "text-muted-foreground/45 hover:text-amber-400"}`}
                  title={item.reminderEnabled !== false ? "Reminders on: 5 minutes before and at start" : "Enable task reminders"} aria-pressed={item.reminderEnabled !== false}>
                  <Bell size={12} fill={item.reminderEnabled !== false ? "currentColor" : "none"} />
                </button>

                {/* Delete */}
                <button
                  onClick={() => setSchedule(s => s.filter(i => i.id !== item.id))}
                  className="p-1 rounded text-muted-foreground/55 hover:text-destructive hover:bg-destructive/10 transition-all flex-shrink-0 ml-1"
                  title="Delete event"
                >
                  <Trash2 size={11} />
                </button>
              </div>
            );
          })}
        </div>

        {/* ── Footer ───────────────────────────────────────────── */}
        <div className="px-4 pt-1 pb-4 flex gap-2 border-t border-border mt-1">
          <button onClick={handleExport}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-muted-foreground hover:text-foreground bg-secondary/40 hover:bg-secondary transition-colors mt-2"
          >
            <Download size={12} /> Export
          </button>
          <button onClick={handleImport}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-muted-foreground hover:text-foreground bg-secondary/40 hover:bg-secondary transition-colors mt-2"
          >
            <Upload size={12} /> Import
          </button>
        </div>

        <p className="border-t border-border mt-1 px-4 py-3 text-center text-[9px] tracking-widest uppercase text-muted-foreground/25">
          uxFocus v2.0 &middot; Productivity without distraction
        </p>
      </div>

    </div>
  );
}


