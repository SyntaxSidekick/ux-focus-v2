export function getRemainingSessionSecs(item, now = new Date()) {
  if (!item) return 0;
  const toSeconds = time => {
    const [hours, minutes] = time.split(":").map(Number);
    return (hours * 60 + minutes) * 60;
  };
  const end = toSeconds(item.endTime ?? item.end);
  const current = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  return Math.max(0, end - current);
}
