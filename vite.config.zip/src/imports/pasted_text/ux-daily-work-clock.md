🎯 UX Daily Work Clock - Enhanced Edition
A beautiful, feature-rich productivity widget that keeps you on track throughout your day.

✨ Features
Core Features
⏰ Live Clock - Real-time clock display
🧠 Smart Schedule Tracking - Automatically shows your current schedule block
🍅 Built-in Pomodoro Timer - 45-minute focus sessions for deep work
📍 Fixed Position - Stays in view (top-left corner by default)
🆕 New Enhanced Features
🔊 Custom Audio System
Soft Start Chime - Pleasant ascending tones (C5 → E5 → G5) when starting tasks
Strong End Chime - Attention-grabbing descending tones when stopping
Block-Specific Sounds - Different chimes for:
Deep Work blocks (pure focus tone)
Break blocks (gentle double tone)
Other blocks (default pleasant chime)
No More Harsh Alerts - Uses Web Audio API for smooth, professional sounds
📊 Progress Bar
Visual progress indicator for current schedule block
Real-time updates showing how much time has elapsed
Color-coded (blue) with smooth animations
🎯 Auto-Start Pomodoro
Automatically starts Pomodoro timer when "Deep Work" blocks begin
Toggle on/off in settings
Plays start chime when auto-starting
Saves your preference to localStorage
🧩 Drag & Resize Widget
Drag - Click and drag the clock header to move anywhere on screen
Resize - Use the resize handle (bottom-right) to adjust width
Position and size are automatically saved
Minimum width: 250px for readability
🌙 Dark Mode Toggle
Beautiful dark theme with proper contrast
One-click toggle (moon/sun icon)
Preference saved across sessions
Smooth transitions
💾 Persistent Storage
All settings saved to localStorage:
Custom schedules
Dark mode preference
Auto-start Pomodoro setting
Widget position and size
Everything persists across browser sessions
🚀 Quick Start
React App (Web)
Install dependencies:

npm install lucide-react
Import the component:

import UXClockWidget from './ux_day_clock_widget';

function App() {
  return (
    <div>
      <UXClockWidget />
      {/* Your other components */}
    </div>
  );
}
Make sure you have shadcn/ui components:

npx shadcn-ui@latest add card button
Electron Desktop App (Recommended)
Turn this into a standalone desktop app that floats over ALL windows:

Install Electron dependencies:

npm install --save-dev electron electron-builder concurrently wait-on
Update your package.json:

Copy contents from package-electron.json
Or merge the scripts section
Development mode:

npm run electron-dev
This starts both React dev server and Electron

Build standalone app:

npm run electron-build
Creates installer in dist/ folder

Electron Features
✅ Borderless, transparent window
✅ Always-on-top (floats over everything)
✅ Frameless design
✅ Minimal taskbar presence
✅ Cross-platform (Windows, Mac, Linux)
⚙️ Configuration
Default Schedule
const defaultSchedule = [
  { label: "Deep Work 1", start: "06:30", end: "08:00", sound: "deepwork" },
  { label: "Break", start: "08:00", end: "08:20", sound: "break" },
  { label: "Deep Work 2", start: "08:20", end: "09:30", sound: "deepwork" },
  // ... customize as needed
];
Sound Types
"deepwork" - Single pure focus tone (440 Hz - A4)
"break" - Gentle double tone (D5 → B4)
"default" - Standard notification (C5)
Customizing Your Schedule
Edit the defaultSchedule array in the component to match your routine:

{ 
  label: "Your Task Name", 
  start: "HH:MM", 
  end: "HH:MM", 
  sound: "deepwork" | "break" | "default" 
}
🎨 UI Controls
Top Bar
Clock Time - Drag this area to move the widget
Sun/Moon Icon - Toggle dark mode
Settings Icon - Open settings panel
Settings Panel
Auto-start Pomodoro - Toggle automatic Pomodoro for Deep Work blocks
Pomodoro Controls
Start - Begin 25-minute timer (plays start chime)
Stop - Pause timer (plays end chime)
Reset - Reset to 25:00
Widget Controls
Drag - Click header to move
Resize - Click/drag bottom-right resize icon
🧠 Psychology Notes (Why This Works)
Gentle Audio Cues
Start chimes - Ascending tones create positive association, reduce anxiety
End chimes - Descending tones signal completion without being jarring
Block transitions - Contextual sounds help brain switch modes
Visual Progress
Progress bar provides clear feedback on time remaining
Reduces constant clock-checking
Creates sense of accomplishment as bar fills
Auto-Start Feature
Removes decision fatigue ("should I start a Pomodoro?")
Creates consistent deep work rhythm
Ritual/cue association strengthens over time
Always-On-Top (Electron)
Gentle constant reminder without being intrusive
Reduces alt-tab context switching
Peripheral awareness keeps you accountable
📦 Project Structure
26-daily-work-clock/
├── ux_day_clock_widget.jsx    # Main React component (enhanced)
├── electron-main.js            # Electron app entry point
├── package-electron.json       # Electron build configuration
└── README.md                   # This file
🛠️ Technical Details
Audio System
Uses Web Audio API (AudioContext, OscillatorNode)
Pure sine waves for pleasant, non-harsh tones
Exponential gain ramping for smooth fade-out
No external audio files needed
State Management
React hooks (useState, useEffect, useRef)
localStorage for persistence
Ref-based previous value tracking for block change detection
Drag & Resize
Mouse event handlers with position delta calculation
Boundary constraints (minimum width)
Smooth cursor feedback
Persists to localStorage
🔮 Future Ideas
Want even more features? Consider adding:

📈 Productivity Analytics - Track time spent in each block
🎵 Custom Sound Upload - Let users add their own chimes
🔔 Desktop Notifications - System notifications for block changes
📅 Multiple Schedules - Switch between weekday/weekend schedules
🌈 Theme Customization - Custom colors and styles
⌨️ Keyboard Shortcuts - Global hotkeys for Pomodoro control
📱 Mobile App - React Native version
☁️ Cloud Sync - Sync settings across devices